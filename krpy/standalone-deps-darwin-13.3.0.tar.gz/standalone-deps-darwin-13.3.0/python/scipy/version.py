
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.14.0'
version = '0.14.0'
full_version = '0.14.0'
git_revision = 'f2ec91c4908f9d67b5445fbfacce7f47518b35d1'
release = True

if not release:
    version = full_version
